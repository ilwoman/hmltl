from flask import Flask
import os

#创建和设置app
def create_app(config = None):
    sq_app = Flask(__name__)
    #支持不同方式去读取配置
    #有些功能需要将配置读取到核心对象的config属性里才会生效
    #从config.settings里面读取配置,settings里的配置最好大写
    #把配置读入核心对象的config属性里
    # 原码：
    # if isinstance(obj, str):
    #     obj = import_string(obj)
    # for key in dir(obj):
    #     if key.isupper():
    #         self[key] = getattr(obj, key)
    sq_app.config.from_object('config.settings')

    #根据系统环境变量指定配置文件读取
    if 'FLASK_CONF' in os.environ:
        sq_app.config.from_envvar("FLASK_CONF")

    #根据传参来读取配置
    if config is not None:
        if isinstance(config, dict):
            sq_app.config.update(config)


    #绑定蓝图
    import router   #运行到位
    router.init_app(sq_app)    #蓝图绑定到核心对象sq_app上

    #绑定orm模型
    import model
    model.init_db_app(sq_app)

    return sq_app
