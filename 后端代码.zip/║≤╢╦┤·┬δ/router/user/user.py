from . import user_bp
from flask_restful import Resource, Api
from libs.response import content_rsp
from flask import request
# 发送纯文本
import smtplib
# 邮件正文
from email.mime.text import MIMEText
import random
from model.userdb import RegistCodeInfo, UserInfo

#绑定蓝图
api = Api(user_bp)

# 发送验证码
def sendMail(mail_user, mail_pwd, sender, receiver, content, title):
    mail_host = "smtp.qq.com"  # qq的SMTP服务器
    # 第一部分：准备工作
    # 1.将邮件的信息打包成一个对象
    message = MIMEText(content, "plain", "utf-8")  # 内容，格式，编码
    # 2.设置邮件的发送者
    message["From"] = sender
    # 3.设置邮件的接收方
    # message["To"] = receiver
    # join():通过字符串调用，参数为一个列表
    message["To"] = ",".join(receiver)
    # 4.设置邮件的标题
    message["Subject"] = title

    # 第二部分：发送邮件
    try:
        # 1.启用服务器发送邮件
        # 参数：服务器，端口号
        smtpObj = smtplib.SMTP()
        smtpObj.connect(mail_host, 25)  # 25 为 SMTP 端口号
        # 2.登录邮箱进行验证
        # 参数：用户名，授权码
        smtpObj.login(mail_user, mail_pwd)
        # 3.发送邮件
        # 参数：发送方，接收方，邮件信息
        smtpObj.sendmail(mail_user, receiver, message.as_string())
        return 1
    except:
        return 0

# 注册
class Register(Resource):
    #获取验证码
    def get(self):
        # 接收者邮箱
        mail_receiver = request.args.get("email")
        print(mail_receiver)
        # 发送者邮箱
        mail_user = "1959244045@qq.com"
        mail_pwd = "ovkhjussbvgqfbfe"
        mail_sender = "1959244045@qq.com"
        yzm = ""
        for i in range(6):
            ch = chr(random.randrange(ord('0'), ord('9') + 1))
            yzm += ch
        email_content = "您的验证码为：%s" % yzm
        email_title = "learnEnglishApp用户注册验证码"

        flag = sendMail(mail_user, mail_pwd, mail_sender,
                 mail_receiver, email_content, email_title)
        if flag == 1:
            user = RegistCodeInfo.query.filter(RegistCodeInfo.user_email == mail_receiver).first()
            if user:
                RegistCodeInfo.modify_code(user.user_id, yzm)
            else:
                RegistCodeInfo.add_code(mail_receiver, yzm)
            return content_rsp(code=0, message="获取验证码成功".encode('utf-8'). decode('utf-8'))
        else:
            return content_rsp(code=10001, message="获取验证码失败".encode('utf-8'). decode('utf-8'))

    # 用户注册
    def post(self):
        data = request.json
        mail = data.get("mail")
        code = data.get("yzm")
        password = data.get("password")
        print(mail, code, password)
        user = RegistCodeInfo.query.filter(RegistCodeInfo.user_email == mail).first()
        if user:
            if user.user_authcode != code:
                return content_rsp(code=10001, message="验证码错误")
            else:
                UserInfo.add_user(user.user_id, password)
                return content_rsp(code=0, message="注册成功")
        else:
            return content_rsp(code=10002, message="注册失败")

api.add_resource(Register, "/register")

# 检查邮箱号是否已经注册
class Check(Resource):
    def get(self):
        email = request.args.get("email")
        user = RegistCodeInfo.query.filter(RegistCodeInfo.user_email == email).first()
        print(user.userinfo.user_password)
        if user.userinfo.user_password:
            return content_rsp(code=10001, message="邮箱号已被注册")
        else:
            return content_rsp(code=0)

api.add_resource(Check, "/check")
