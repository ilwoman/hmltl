# from flask import Flask
# app = Flask(__name__)
# app.run()   #开发环境，内置小型web服务器

#web服务器
# nginx web服务器
# gunicorn / uwsgi -- python web服务器

#http协议 -- 超文本传输协议

#如何接收http请求，如何解析http请求，如何发送http响应？
#底层的tcp连接，http协议的解析，全部交由专门的服务器软件实现。(web服务器)
#我们只需要专注生成html文档，注重业务逻辑。

#WSGI -- python web server gateway interface
#是python语言定义的web服务器和web应用程序之间一种简单而通用的接口规范。

#wsgi服务器 -- gunicorn
#安装gunicorn
# pip3 install gunicorn
#编辑测试文件
# [root@aliyun sq-flask-test]# cat flask-test1.py
# from flask import Flask
# app = Flask(__name__)

#使用gunicorn运行程序，线上环境
# [root@aliyun sq-flask-test]# gunicorn flask-test1:app
# [2023-09-01 15:38:20 +0800] [4077664] [INFO] Starting gunicorn 21.2.0
# [2023-09-01 15:38:20 +0800] [4077664] [INFO] Listening at: http://127.0.0.1:8000 (4077664)
# [2023-09-01 15:38:20 +0800] [4077664] [INFO] Using worker: sync
# [2023-09-01 15:38:20 +0800] [4077667] [INFO] Booting worker with pid: 4077667

# #导入Flask类
# from flask import Flask
# #创建核心对象
# #后续所有的东西都要和app绑定
# app = Flask(__name__)  #实例化
# #启动web服务器，默认绑定 127.0.0.1:5000端口
# #0.0.0.0代表本机上的任意ip
# app.run(host="0.0.0.0")

#不同端口区分不同服务

#一个模块的运行有两种方式
# 导入运行  __name__ == "模块的绝对路径名"
# 直接运行  __name__ == "__main__"
# import main_test  #导入运行
# main_test.print_hi("sc")

##################flask 路由
from flask import Flask
sq_app = Flask(__name__)

#路由和视图函数绑定
@sq_app.route("/")
def hello():
    return "hello, world!"

@sq_app.route("/home")
def home():
    return "this is home!"

def user():
    return "this is user_test"

sq_app.add_url_rule("/user_test", view_func=user, endpoint="user_test")

#flask 路由管理：通过两张表进行管理 url_map和view_functions表
#url_map：保存的是url和endpoint的映射关系
#view_functions：保存的是endpoint和视图函数的映射关系
#当用户请求过来的时候，通过用户请求的url在url_map表中找对应的endpoint，
#拿到endpoint之后再去view_functions找对应的视图函数

#没有明确指定endpoint，endpoint就取函数名
#endpoint全局唯一
#endpoint重复会抛出下面的断言异常
#AssertionError: View function mapping is overwriting an existing endpoint function: home

#构造动态url -- 通过url路径传递参数
#http://10.109.84.152:5000/login/root/123456
@sq_app.route("/login/<username>/<passwd>")
def login(username, passwd):
    return f"username is {username}, passwd is {passwd}"

#/stu/age -- age是动态的
#如果age >= 18，允许上网；age < 18,未成年，不允许上网
@sq_app.route("/stu/<age>", methods=["GET", "POST"])
def stu(age):
    if int(age) >= 18:
        return "允许上网"
    else:
        return "未成年，不允许上网"

#debug = True 开启debug模式，修改代码，自动加载。在开发环境使用，发生错误会输出更多的信息，方便排错
sq_app.run(host="0.0.0.0", debug=True, port=8000)
