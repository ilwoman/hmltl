#配置文件
HOST = "0.0.0.0"
PORT = 9000
DEBUG = True

#token 过期时间设置
EXPIRES_IN = 600
SECRET_KEY = "ABCXYZ"

SQLALCHEMY_DATABASE_URI = 'mysql+pymysql://sc:123456@192.168.216.133/learnEnglishApp?charset=utf8'
