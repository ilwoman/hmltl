from flask_sqlalchemy import SQLAlchemy

db = SQLAlchemy()  #返回一个orm模型实例

def init_db_app(app):
    db.init_app(app)

from . import userdb
