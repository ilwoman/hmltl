from model import db

# 注册邮箱验证码表
class RegistCodeInfo(db.Model):
    __tablename__ = "registcodeinfo"
    user_id = db.Column(db.Integer, primary_key=True, autoincrement=True)
    user_email = db.Column(db.String(128), nullable=False)
    user_authcode = db.Column(db.String(12), nullable=False)
    # 建立表与表之间的联系 relationship -- orm层
    userinfo = db.relationship("UserInfo", backref="registcode", uselist=False)  # 一对一

    #新增验证数据
    @classmethod
    def add_code(cls, email, code):
        user = cls()  # 实例化
        user.user_email = email
        user.user_authcode = code
        # 生效到数据库
        db.session.add(user)
        db.session.commit()

    #修改验证数据
    @classmethod
    def modify_code(cls, id, code):
        user = cls.query.get(id)
        user.user_authcode = code
        # 生效到数据库
        db.session.add(user)
        db.session.commit()

# 用户密码表
class UserInfo(db.Model):
    __tablename__ = "userinfo"
    user_id = db.Column(db.ForeignKey("registcodeinfo.user_id"), primary_key=True)
    user_password = db.Column(db.String(128), nullable=False)

    #新增用户数据
    @classmethod
    def add_user(cls, id, password):
        user = cls()  # 实例化
        user.user_id = id
        user.user_password = password
        # 生效到数据库
        db.session.add(user)
        db.session.commit()
