#pymysql --- python用来连接mysql数据库的模块
import pymysql

#打开数据库连接
db = pymysql.connect(host="192.168.216.132",
                     user='sc',
                     password='123456',
                     database="sqflask")

#创建一个游标对象
cur = db.cursor()

#execute()执行sql查询
cur.execute("select * from stuinfo")
#获取数据
data = cur.fetchall()
print(data)
db.close()
