################接收客户端传递的参数
#1.构造动态url
#2.request对象：客户端请求的所有信息全部都封装在这个对象里
#常用属性：
#url 记录请求的url地址
#method 记录请求中的http方法
#path 记录url中的资源定位地址
#args 记录请求中的查询参数
# ?后面的就是查询参数
# http://127.0.0.1:5000/login?username=root&passwd=123456
#json 记录请求中传递的json格式数据
#form 记录请求中传递的表单格式数据，适合非前后端分离项目

from flask import Flask, request
app = Flask(__name__)

@app.route("/login", methods=["POST"])
def login():
    # print(dir(request))
    # print(request.url)
    # print(request.path)

    # print(request.args)
    # print(request.args.get("username"))

    #服务端规定使用什么方式去传递数据，客户端就按照相应方式传递
    #服务端需要什么key，客户端就要给什么key
    # print(request.json)
    #传递用户名和密码 --> UserName, PassWord
    #判断用户名是不是sc，密码是不是123456
    #返回提示登录成功/失败
    # if request.json.get("UserName") == "sc" and request.json.get("PassWord") == "123456":
    #     return "登录成功！"
    # return "登录失败！"

    print(request.form)
    return "this is login"

app.run(debug=True)

##############如何组织项目
#各个功能模块
#拆分成不同的目录去维护
#main.py app/app.py config/setting
