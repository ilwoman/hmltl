import pymysql

def create_db():
    db = pymysql.connect(host="192.168.216.133",
                         user='sc',
                         password='123456',
                         database="learnEnglishApp")
    return db
