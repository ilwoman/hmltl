#标准化返回
#标准化、流程化
#返回json格式
#包含三个字段：code、data、message
#code -- 表示应用的状态码
#        先设计好 成功--0，失败--登录失败(1)、注册失败(2)
#message -- 对状态码的说明

def content_rsp(data=None, message="success!", code=0):
    #约定数据返回格式
    if data is None:
        data = []

    return {
        "code": code,
        "message": message,
        "data": data
    }
