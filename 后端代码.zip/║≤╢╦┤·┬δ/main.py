#所有文件要从程序入口开始，运行到位
#所有东西要和核心对象做绑定
from app.app import create_app
app = create_app()

# from router import test
# app.register_blueprint(test.test_bp)

# from router.test import test_bp
# app.register_blueprint(test_bp)

#数据库迁移工具，数据库版本管理 -- flask-migrate
#使用的时候需要用到flask cli
from flask_migrate import Migrate
from model import db

migrate = Migrate(app, db)

if __name__ == "__main__":
    app.run(debug=app.config["DEBUG"],
            host=app.config["HOST"],
            port=app.config["PORT"])

#flask 命令行管理 版本迁移 -- flask cli 自带
#初始化 -- 创建migrations文件夹
# flask --app main:app db init
#提交版本
# flask --app main:app db migrate
#生效到数据库
# flask --app main:app db upgrade

#migrate因为版本问题没生效，直接删除migrations目录以及数据库中的版本记录表即可
