import os
print(os.path)