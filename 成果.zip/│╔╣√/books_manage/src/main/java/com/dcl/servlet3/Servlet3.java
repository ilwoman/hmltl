package com.quanyan.servlet3;

import java.io.IOException;
import java.sql.DriverManager;

import javax.servlet.ServletException;
//import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import com.mysql.jdbc.Connection;
import com.mysql.jdbc.Statement;

/**
 * Servlet implementation class Servlet3
 */
//@WebServlet("/Servlet3")
public class Servlet3 extends HttpServlet {
	private static final long serialVersionUID = 1L;
       
    /**
     * @see HttpServlet#HttpServlet()
     */
    public Servlet3() {
        super();
        // TODO Auto-generated constructor stub
    }

	/**
	 * @see HttpServlet#doGet(HttpServletRequest request, HttpServletResponse response)
	 */
	protected void doGet(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		// TODO Auto-generated method stub
		response.getWriter().append("Served at: ").append(request.getContextPath());
		request.setCharacterEncoding("UTF-8");
		response.setContentType("text/html;charset=UTF-8");
		String bookId = request.getParameter("bookid");
        String title = request.getParameter("title");  
        String author = request.getParameter("author");  
        String publisher = request.getParameter("publisher");  
        double price = Double.parseDouble(request.getParameter("price"));  
        
        try { 
            Class.forName("com.mysql.jdbc.Driver");
            Connection conn = (Connection) DriverManager.getConnection("jdbc:mysql://127.0.0.1:3306?characterEncoding=utf8", "root", "123456");
            Statement stmt = (Statement) conn.createStatement();
            response.getWriter().print(bookId);
            String sql =  "UPDATE postgres.books SET title = '" + title + "', author = '" + author + "', publisher = '" + publisher + "', price = " + price + " WHERE bookid = '" + bookId + "'"; 
            response.getWriter().print(sql);
//            response.getWriter().print(bookId);
            stmt.executeUpdate(sql);
            response.getWriter().print(bookId);
            stmt.close();
            conn.close();  
        } catch (Exception e) {  
            e.printStackTrace();  
        }  
	}

	/**
	 * @see HttpServlet#doPost(HttpServletRequest request, HttpServletResponse response)
	 */
	protected void doPost(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		// TODO Auto-generated method stub
		doGet(request, response);
	}

}
