package com.quanyan.servlet4;

import java.io.IOException;
import java.io.PrintWriter;
import java.sql.DriverManager;
import java.sql.ResultSet;

import javax.servlet.ServletException;
//import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import com.mysql.jdbc.Connection;
import com.mysql.jdbc.Statement;

/**
 * Servlet implementation class Servlet4
 */
//@WebServlet("/Servlet4")
public class Servlet4 extends HttpServlet {
	private static final long serialVersionUID = 1L;
       
    /**
     * @see HttpServlet#HttpServlet()
     */
    public Servlet4() {
        super();
        // TODO Auto-generated constructor stub
    }

	/**
	 * @see HttpServlet#doGet(HttpServletRequest request, HttpServletResponse response)
	 */
	protected void doGet(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		// TODO Auto-generated method stub
		request.setCharacterEncoding("UTF-8");
		response.setContentType("text/html;charset=UTF-8");
		String bookId = request.getParameter("bookid");
		PrintWriter out = response.getWriter();  
        
        try { 
            Class.forName("com.mysql.jdbc.Driver");
            Connection conn = (Connection) DriverManager.getConnection("jdbc:mysql://127.0.0.1:3306?characterEncoding=utf8", "root", "123456");
            Statement stmt = (Statement) conn.createStatement();
            String query = "SELECT * FROM postgres.books WHERE bookid='" + bookId + "'";  
            ResultSet rs = stmt.executeQuery(query);  
            if (rs.next()) {  
                out.println("<html>");  
                out.println("<head>");  
                out.println("<title>书籍查询结果</title>");  
                out.println("</head>");  
                out.println("<body>");  
                out.println("<h1>书籍查询结果</h1>");  
                out.println("<table border='1'>");  
                out.println("<tr><th>书号</th><th>书名</th><th>作者</th><th>出版社</th><th>价格</th></tr>");  
                out.println("<tr><td>" + rs.getString("bookid") + "</td><td>" + rs.getString("title") + "</td><td>" + rs.getString("author") + "</td><td>" + rs.getString("publisher") + "</td><td>" + rs.getDouble("price") + "</td></tr>");  
                out.println("</table>");  
                out.println("</body>");  
                out.println("</html>");
                rs.close();  
                stmt.close();  
                conn.close();  
            } else {  
                out.println("<p>没有找到相关书籍。</p>");  
            }  
        } catch (Exception e) {  
            e.printStackTrace();  
        }  
	}

	/**
	 * @see HttpServlet#doPost(HttpServletRequest request, HttpServletResponse response)
	 */
	protected void doPost(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		// TODO Auto-generated method stub
		doGet(request, response);
		request.setCharacterEncoding("UTF-8");
		response.setContentType("text/html;charset=UTF-8");
	}

}
