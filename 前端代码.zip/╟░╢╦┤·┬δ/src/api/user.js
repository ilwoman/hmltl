import serviceAxios from '@/utils/serviceAxios'

// 检查邮箱号是否已经被注册
export const checkUsername = (username) => {
	return serviceAxios({
		url: "/check?email=" + username,
		method: "get"
	})
}

// 获取邮箱验证码
export const getNum = (username) => {
	return serviceAxios({
		url: "/register?email=" + username.value,
		method: "get"
	})
}

// 用户注册
export const createUser = (data) => {
	return serviceAxios({
		url: "/register",
		method: "post",
		data: data,
		// data
	})
}

// 用户登录   {"username":"cc", "password": "123"}
export const login = (data) => {
	return serviceAxios({
		url: "/auth/login",
		method: "post",
		data: data,
		// data
	})
}
