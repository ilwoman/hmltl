import {createRouter, createWebHistory} from 'vue-router'
// ./routes => 自定义文件 => 定义了所有的路由信息
import {routes} from './routes'

// 创建路由模块 => 参数1:历史记录模式(URL模式),参数2:定义的路由信息
const router = createRouter({
	history: createWebHistory(),
	routes
})

export default router