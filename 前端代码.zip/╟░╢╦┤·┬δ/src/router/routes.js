//定义url匹配规则
export const routes = [
	//每个路由都是一个Object
	{
		path: "/init",
		name: "init",
		component: () => import("_c/test/init.vue")
	},
	{
		path: "/regist",
		name: "regist",
		component: () => import("_v/regist/Regist.vue")
	},
	{
		path: "/login",
		name: "login",
		component: () => import("_v/login/Login.vue")
	},
	{
		path: "/findpassword",
		name: "findpassword",
		component: () => import("_v/findpassword/findPassword.vue")
	},
	{
		path: "/tabbar",
		name: "tabbar",
		component: () => import("_c/tabbar/tabBar.vue")
	},
	{
		path: "/",
		name: "dashboard",
		component: () => import("_c/tabbar/tabBar.vue"),
		children: [
			// {
			// 	//如果只输入一个/,默认匹配/home
			// 	path: "/",
			// 	redirect: "home"
			// },
			{
				path: "usercenter",
				name: "usercenter",
				component: () => import("_v/usercenter/userCenter.vue")
			},
		]
	}
]