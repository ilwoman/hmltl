const serverConfig = {
	baseURL: "/api", // 请求基础地址,可根据环境自定义
	useTokenAuthorization: true, // 是否开启 token 认证
	loginName: 'login',
};
export default serverConfig;