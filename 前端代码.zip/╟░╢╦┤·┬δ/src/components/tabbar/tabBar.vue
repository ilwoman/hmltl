<template>
    <router-view></router-view>
    <van-tabbar v-model="active">
        <van-tabbar-item name="home" icon="home-o" to="/home">主页</van-tabbar-item>
        <van-tabbar-item name="learn" icon="edit" :to="{ name: 'about' }">学习</van-tabbar-item>
        <van-tabbar-item name="bookshop" icon="send-gift-o" :to="{ name: '' }">书城</van-tabbar-item>
        <van-tabbar-item name="usercenter" icon="user-circle-o" :to="{ name: 'usercenter' }">我的</van-tabbar-item>
    </van-tabbar>
</template>
<script setup>
import { ref } from 'vue';
const active = ref('home');

</script>
<style></style>