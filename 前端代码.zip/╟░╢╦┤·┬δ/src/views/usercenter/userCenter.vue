<template>
    <div class="ico order">
        <a href=""><van-icon name="setting-o" /></a>
        <a href=""><van-icon name="chat-o" /></a>
    </div>
    <div class="box left order">
        <div class="left">
            <van-image round width="5rem" height="5rem" src="../../../public/touXiang.jpg" />
        </div>
        <div class="left box2">
            <div style="font-size: 20px;font-weight: 700;">QuanY</div>
            <div class="top">Spark You···</div>
        </div>
        <div class="right"><a href="">个人信息&nbsp;&nbsp;></a></div>
    </div>
    <div class="left order">
        <van-grid>
            <van-grid-item icon="cart" text="我的订单" to="/login" />
            <van-grid-item icon="down" text="离线中心" />
            <van-grid-item icon="star" text="我的收藏" />
            <van-grid-item icon="location" text="收货地址" />
        </van-grid>
    </div>
    <div class="left order cell">
        <van-cell icon="bag" title="积分商城" is-link />
        <van-cell icon="column" title="错题本" value="90题" is-link />
        <van-cell icon="coupon" title="优惠券" value="0张" is-link />
        <van-cell icon="clock" title="考试倒计时" value="1个" is-link />
        <van-cell icon="comment-circle" title="在线咨询" value="09:00-19:00" is-link />
        <van-cell icon="phone-circle" title="客服热线" value="09:00-19:00" is-link />
        <van-cell icon="warning" title="关于我们" is-link />
    </div>
</template>
<script setup>

</script>

<style>
.ico {
    width: 100%;
    height: 20px;
    font-size: 30px;
    margin-top: 20px;
}

.ico a {
    color: black;
}

.van-icon-chat-o {
    float: right;
    margin-right: 20px;
}

.van-icon-setting-o {
    float: right;
    margin-right: 20px;
}

.box {
    margin: 9px;
    background-color: #fff;
}

.left {
    float: left;
}

.box2 {
    margin-top: 20px;
    margin-left: 30px;
}

.right {
    float: right;
    margin-right: 20px;
    margin-top: 30px;
}

.right a {
    color: gray;
}

.top {
    margin-top: 18px;
}

.order {
    margin-top: 12px;
    color: gray;
    width: 90%;
    margin-left: 16px;
}

.order .van-grid-item__icon {
    color: rgb(28, 173, 230);
}

.cell {
    /* --van-cell-border-color: black; */
    --van-cell-line-height: 30px;
    --van-cell-font-size: 16px
}

.cell .van-cell__left-icon {
    color: rgb(67, 133, 232);
}
</style>