<template>
    <h1 class="center">邮箱注册</h1>
    <van-form @submit="onSubmit" ref="registForm">
        <van-cell-group inset>
            <van-field v-model="username" name="mail" placeholder="请输入您的邮箱号" :rules="[{ required: true, message: '请填写邮箱' },
            { pattern, message: '不是合法的邮箱号' }, { validator: checkUserRepete, message: '用户名已存在' }]" />
            <van-field v-model="inputYzm" type="text" name="yzm" placeholder="请输入邮箱验证码"
                :rules="[{ required: true, message: '请填写验证码' }]">
                <template #button>
                    <van-button size="small" type="primary" @click="getCode" :disabled="text === '获取验证码' ? false : true">{{
                        text }}</van-button>
                </template>
            </van-field>
            <van-field v-model="password" type="password" name="password" placeholder="请输入密码"
                :rules="[{ required: true, message: '请填写密码' }, { validator: checkPasswd, message: '密码复杂度过低' }]" />
        </van-cell-group>
        <div style="margin: 16px;font-size: 14px;"><van-checkbox v-model="checked">我已阅读并同意<a href="">《用户服务协议》</a>和<a
                    href="">《隐私协议》</a></van-checkbox></div>
        <div style="margin: 16px;">
            <van-button round block type="primary" native-type="submit">
                注册
            </van-button>
        </div>
    </van-form>
    <div class="right side-margin">
        <router-link to="/login">登录</router-link>
    </div>
</template>
<script setup>
import { ref } from 'vue';
import router from '@/router'
import { checkUsername, getNum, createUser } from '@/api/user.js'
const username = ref('');
const password = ref('');
const checked = ref(false);
const inputYzm = ref('');
import { showFailToast, showSuccessToast } from 'vant'
import 'vant/es/toast/style';

// 检查邮箱号是否已经注册
const checkUserRepete = (val) => {
    console.log("检查用户名是否已存在")
    console.log(val)
    var result = checkUsername(val)
        .then(res => {
            console.log("调用接口成功")
            if (res.code == 0) {
                return true
            } else {
                return res.message
            }

        })
        .catch(err => {
            console.log("调用接口失败")
            return err
        })

    return result
}

// 验证邮箱格式是否正确
const pattern = /^[a-zA-Z0-9_-]+@[a-zA-Z0-9_-]+(.[a-zA-Z0-9_-]+)+$/

const text = ref("获取验证码");
// 获取邮箱验证码
const getCode = () => {
    console.log(username.value)
    let n = 60;
    text.value = n + "秒钟重新获取";
    const timer = setInterval(() => {
        if (n === 0) {
            clearInterval(timer);
            text.value = "获取验证码";
        } else {
            if (n == 55) {
                getNum(username)
                    .then(res => {
                        console.log("正在获取验证码")
                        if (res.code == 0) {
                            showSuccessToast({
                                "message": "验证码获取成功！",
                                "position": "top"
                            })
                        } else {
                            showFailToast({
                                "message": res.message,
                                "position": "top"
                            })
                        }

                    })
                    .catch(err => {
                        console.log("调用接口失败")
                        return err
                    })
            }
            n--;
            text.value = n + "秒钟重新获取";
        }
    }, 1000);
};

// 验证密码复杂性
// 匹配一个长度在8到30个字符之间（包括8和30）的字符串，这个字符串必须包含至少一个数字和一个字母。
const pwdRegex = new RegExp('(?=.*[0-9])(?=.*[a-zA-Z]).{8,30}')
const checkPasswd = (val) => {
    if (pwdRegex.test(password.value))
        return true
    else
        return false
}

const onSubmit = (values) => {
    console.log('submit', values);
    // 注册用户
    createUser(values)
        .then(res => {
            // res => 接口的返回值  => serviceAxios 响应  data
            if (checked.value) {
                if (res.code == 0) {
                    console.log("注册成功，跳转到login页面")
                    showSuccessToast({
                        "message": "注册成功！",
                        "position": "top"
                    })
                    router.push({
                        name: "login"
                    })
                } else {
                    // console.log("注册失败，原因是：",res.message)
                    showFailToast({
                        "message": res.message,
                        "position": "top"
                    })
                }
            }
            else {
                showFailToast({
                    "message": '未勾选用户协议',
                    "position": "top"
                })
            }

        })
        .catch(err => {
            // err =>  serviceAxios 响应  reject.message
            console.log("执行出错了,", err)
            showFailToast({
                "message": err,
                "position": "top"
            })
        })
};

</script>
<style>
.side-margin {
    margin: 0px 15px;
}

.side-margin a {
    color: rgb(71, 182, 225);
}

.right {
    text-align: right;
}
</style>