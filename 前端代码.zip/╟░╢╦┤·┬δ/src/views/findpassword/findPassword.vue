<template>
    <h2 class="left">找回密码</h2>
    <van-form @submit="onSubmit" ref="registForm">
        <van-cell-group inset>
            <van-field v-model="username" name="手机号" placeholder="请输入您的手机号" :rules="[{ required: true, message: '请填写手机号' },
            { pattern, message: '不是合法的手机号' }]" />
            <van-field v-model="inputYzm" type="password" name="验证码" placeholder="请输入短信验证码"
                :rules="[{ required: true, message: '请填写验证码' }]">
                <template #button>
                    <van-button size="small" type="primary" @click="getCode" :disabled="text === '获取验证码' ? false : true">{{
                        text }}</van-button>
                </template>
            </van-field>
            <van-field v-model="password" type="password" name="密码" placeholder="请输入密码"
                :rules="[{ required: true, message: '请填写密码' }, { validator: checkPasswd, message: '密码复杂度过低' }]" />
        </van-cell-group>
        <div style="margin: 16px;">
            <van-button round block type="primary" native-type="submit">
                完成
            </van-button>
        </div>
    </van-form>
</template>
<script setup>
import { ref } from 'vue';
import router from '@/router'
import { checkUsername, getNum, createUser } from '@/api/user.js'
const username = ref('');
const password = ref('');
const inputYzm = ref('');
var yzm;
const onSubmit = (values) => {
    createUser(values)
        .then(res => {
            // res => 接口的返回值  => serviceAxios 响应  data
            if (yzm == inputYzm.value) {
                if (res.code == 0) {
                    console.log("注册成功，跳转到login页面")
                    showSuccessToast({
                        "message": "注册成功！",
                        "position": "top"
                    })
                    router.push({
                        name: "login"
                    })
                } else {
                    // console.log("注册失败，原因是：",res.message)
                    showFailToast({
                        "message": res.message,
                        "position": "top"
                    })
                }
            }
            else {
                showFailToast({
                    "message": "验证码错误！",
                    "position": "top"
                })
            }

        })
        .catch(err => {
            // err =>  serviceAxios 响应  reject.message
            console.log("执行出错了,", err)
            showFailToast({
                "message": err,
                "position": "top"
            })
        })
    console.log('submit', values);
};
const pattern = /^[1][3,4,5,7,8,9][0-9]{9}$/
import { showFailToast, showSuccessToast } from 'vant'
import 'vant/es/toast/style';
const text = ref("获取验证码");
const getCode = () => {
    let n = 60;
    text.value = n + "秒钟重新获取";
    const timer = setInterval(() => {
        if (n === 0) {
            clearInterval(timer);
            text.value = "获取验证码";
        } else {
            if (n == 55) {
                getNum(username)
                    .then(res => {
                        console.log("正在获取验证码")
                        if (res.code == 0) {
                            showSuccessToast({
                                "message": "验证码获取成功！",
                                "position": "top"
                            })
                            yzm = res.message
                            console.log("验证码为：" + res.message)
                        } else {
                            showFailToast({
                                "message": res.message,
                                "position": "top"
                            })
                        }

                    })
                    .catch(err => {
                        console.log("调用接口失败")
                        return err
                    })
            }
            n--;
            text.value = n + "秒钟重新获取";
        }
    }, 1000);
};
const pwdRegex = new RegExp('(?=.*[0-9])(?=.*[a-zA-Z]).{8,30}')
const checkPasswd = (val) => {
    if (pwdRegex.test(password.value))
        return true
    else
        return false
}
</script>
<style>
.left {
    text-align: left;
    margin: 30px;
}
</style>