<template>
    <van-form @submit="onSubmit">
        <div class="regist" style="margin: 16px;"><router-link to="/regist">注册</router-link></div>
        <div class="center"><img src="../../../public/learnEnglishIco.jpg" alt=""></div>
        <van-cell-group inset>
            <van-field v-model="username" name="手机号" placeholder="请输入您的手机号"
                :rules="[{ required: true, message: '请填写手机号' }]" />
            <van-field v-model="password" type="password" name="密码" placeholder="请输入密码"
                :rules="[{ required: true, message: '请填写密码' }]" />
        </van-cell-group>
        <div style="margin: 16px;font-size: 14px;"><van-checkbox v-model="checked">我已阅读并同意<a href="">《用户服务协议》</a>和<a
                    href="">《隐私协议》</a></van-checkbox></div>
        <div style="margin: 16px;">
            <van-button round block type="primary" native-type="submit">
                登录
            </van-button>
        </div>
        <div class="right" style="margin: 16px;"><router-link to="/findpassword">忘记密码？</router-link></div>
    </van-form>
</template>
<script setup>
import { ref } from 'vue';
const username = ref('');
const password = ref('');
const checked = ref(false);
import { login } from '@/api/user.js'
import router from '@/router'
import { showFailToast, showSuccessToast } from 'vant'
import 'vant/es/toast/style'
const onSubmit = (values) => {
    console.log('submit', values);
    login(values)
        .then(res => {
            if (checked.value) {
                if (res.code == 0) {
                    console.log("成功")
                    // // 存储数据
                    // localStorage.setItem("username", res.data.username)
                    // localStorage.setItem("token", res.data.token)

                    // 提示
                    showSuccessToast({
                        message: "登录成功",
                        position: "top"
                    })
                    // router.push({
                    //     name: "home"
                    // })
                } else {
                    showFailToast({
                        message: res.message,
                        position: "top"
                    })
                }
            }
            else {
                showFailToast({
                    message: '未勾选用户协议！',
                    position: "top"
                })
            }

        })
        .catch(err => {
            showFailToast({
                message: err,
                position: "top"
            })
        })
};
</script>
<style>
html,
body {
    background-color: #fff;
}

img {
    width: 100px;
    height: 100px;
    margin: 10px;
}

.regist {
    float: left;
    height: 16px;
    width: 100%;
}

.regist a,
.right a {
    color: rgb(71, 182, 225);
}

.right {
    text-align: right;
}
</style>