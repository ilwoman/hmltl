import {
	Button,
	Cell,
	CellGroup
} from '@nutui/nutui'

//一个文件中可以有多个export
//但是一个文件只能有一个export default => import xxx from 'xxx.js'
//有多个对象导出时 =>import {xxx} from 'xx.js'
//export导出 只有导出了 另的文件才能import
export const nutUiComponents = [
	Button,
	Cell,
	CellGroup
]
//export default nutUiComponents

//export nutUiComponents
//export default导出