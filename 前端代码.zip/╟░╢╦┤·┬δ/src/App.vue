<script setup>
// import HelloWorld from './components/HelloWorld.vue'
import { showToast, showSuccessToast } from 'vant';
import 'vant/es/toast/style';
import TabBar from "_c/tabbar/TabBar.vue"

function onClick() {
	showSuccessToast("提示信息")
}

</script>

<template>
	<!-- 根据浏览器的路由，决定展示什么内容 -->
	<router-view></router-view>
</template>

<style scoped></style>
