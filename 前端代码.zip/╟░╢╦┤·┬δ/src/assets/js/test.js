export function test(){
	console.log("this is test.js")
}
